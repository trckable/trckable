import{i as e,t}from"./react-e12729a5.js";import{Ar as n,Kr as r,Wr as i,fr as a,zt as o}from"./core-3ff01fef.js";import{t as s}from"./check-636c0dd2.js";import{t as c}from"./DialogActions-182d5027.js";import{t as l}from"./DialogHead-207e9271.js";import{t as u}from"./Modal-a7912826.js";import{t as d}from"./apiMore-946511e4.js";import{t as f}from"./Code-931f0ba3.js";import{t as p}from"./Copyable-dfc0d831.js";import{t as m}from"./Tabs-fe4a22b7.js";var h=e(),g=r(`crawlers.kinds`,[{id:`answer`,label:`AI assistants`,what:`Fetched by an assistant to answer someone right now`},{id:`train`,label:`Training crawlers`,what:`Collected as training data`},{id:`index`,label:`Search bots`,what:`Crawled so your pages can be found`}]),_=r(`crawlers`,{title:`AI assistants & crawlers`,tabs:`What the robot wanted`,feed:`How to feed this`,empty:`Nothing yet. Robots never reach the browser script, so your server forwards them: see “How to feed this”.`,over:e=>`${e} over time`,none:e=>`No ${e.toLowerCase()} in this period.`,errors:(e,t)=>`${e} ${t?`requests`:`request`} hit an error page`,pages:`Pages read`,page:`Page`,bot:`Robot`,hits:`Hits`,other:`Other pages`,folded:e=>`${e} hits counted without their page (fair use)`,setup:{label:`Connect crawler data`,title:`Connect crawler data`,hint:`Robots run no JavaScript: your server or CDN reports them.`,help:`Only the robot’s name, the page and the time are sent. No address, no cookie, no visitor.`,steps:[`Where does your site run?`,`Copy this`,`Turn it on`],options:[{id:`cloudflare`,label:`Cloudflare`},{id:`vercel`,label:`Vercel`},{id:`nginx`,label:`Nginx`},{id:`caddy`,label:`Caddy`},{id:`other`,label:`Other`}],captions:{worker:`A Worker, run after the page has gone out`,middleware:`Middleware, run after the response has gone`,mirror:`Mirror: no extra process, no status`,log:`Log and forwarder: reports the status too`,caddy:`Log and forwarder`,curl:`One POST per robot request`},key:`Key`,keyHint:`Save it as TRCKABLE_PROXY_KEY`,on:`Turn on`,waiting:`Waiting for the first robot`,arrived:e=>`${e} hits arrived`,docs:`Docs`,done:`Done`}}),v=`(other)`,y=[`chatgpt-user`,`oai-searchbot`,`claude-user`,`claude-searchbot`,`perplexity-user`,`perplexitybot`,`google-cloudvertexbot`,`bingbot-chat`,`duckassistbot`,`mistralai-user`,`gptbot`,`claudebot`,`anthropic-ai`,`google-extended`,`meta-externalagent`,`facebookbot`,`bytespider`,`ccbot`,`diffbot`,`omgili`,`timpibot`,`cohere-ai`,`cohere-training-data-crawler`,`mistralai-crawler`,`applebot-extended`],b=(e=`|`)=>y.join(e),x=({host:e,site:t,domain:n})=>`// Cloudflare Worker, on the route ${n}/*
// Settings → Variables and secrets: add the secret TRCKABLE_PROXY_KEY.
const BOTS = /${b()}/i

export default {
  async fetch(request, env, ctx) {
    const response = await fetch(request)
    const ua = request.headers.get('user-agent') || ''
    if (BOTS.test(ua)) {
      // After the page has gone: waitUntil never slows a visitor or a robot.
      ctx.waitUntil(
        fetch('${e}/api/crawl', {
          method: 'POST',
          headers: { 'content-type': 'application/json', 'x-trckable-proxy-key': env.TRCKABLE_PROXY_KEY },
          body: JSON.stringify({ s: '${t}', u: request.url, ua, st: response.status }),
        }).catch(() => {}),
      )
    }
    return response
  },
}`,S=({host:e,site:t})=>`// middleware.ts, next to package.json (Next.js)
// Project → Settings → Environment Variables: add TRCKABLE_PROXY_KEY.
// Other frameworks: the same body inside Vercel's middleware, with waitUntil from '@vercel/functions'.
import { NextResponse, type NextFetchEvent, type NextRequest } from 'next/server'

const BOTS = /${b()}/i

export function middleware(request: NextRequest, event: NextFetchEvent) {
  const ua = request.headers.get('user-agent') || ''
  if (BOTS.test(ua)) {
    event.waitUntil(
      fetch('${e}/api/crawl', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-trckable-proxy-key': process.env.TRCKABLE_PROXY_KEY! },
        body: JSON.stringify({ s: '${t}', u: request.url, ua }),
      }).catch(() => {}),
    )
  }
  return NextResponse.next()
}

export const config = { matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'] }`,C=()=>String.raw`# http { }: the robot's token, or nothing. An address with a quote or a backslash in it is skipped.
map $http_user_agent $trk_bot { default ""; ~*(?<t>${b()}) $t; }
map "$host$request_uri" $trk_url { default "$host$request_uri"; ~[\x22\x5c] ""; }`,w=({host:e,site:t,key:n})=>`${C()}

# server { }
location / {
    mirror /_trckable;
    mirror_request_body off;
    # ... your usual proxy_pass, root or try_files
}
location = /_trckable {
    internal;
    if ($trk_bot = "") { return 204; }
    if ($trk_url = "") { return 204; }
    proxy_pass ${e}/api/crawl;
    proxy_ssl_server_name on;
    proxy_method POST;
    proxy_set_header Content-Type application/json;
    proxy_set_header X-Trckable-Proxy-Key ${n};
    proxy_set_body '{"s":"${t}","u":"https://$trk_url","ua":"$trk_bot"}';
}`,T=(e,t,n)=>`#!/bin/sh
# Reads the log as it grows and reports each robot. Needs jq and curl; run it as a service.
tail -Fn0 "$1" | jq -c --unbuffered '${n}' | while read -r body; do
  curl -s -o /dev/null -X POST ${e}/api/crawl \\
    -H 'content-type: application/json' -H 'X-Trckable-Proxy-Key: ${t}' -d "$body"
done`,E=({host:e,site:t,key:n})=>`${C()}

# http { }: one line per robot, and nothing for anyone else.
log_format trckable escape=json '{"host":"$host","uri":"$request_uri","ua":"$http_user_agent","status":$status}';
access_log /var/log/nginx/trckable.log trckable if=$trk_bot;

# trckable-forward.sh /var/log/nginx/trckable.log
${T(e,n,`{s:"${t}",u:("https://"+.host+.uri),ua:.ua,st:.status}`)}`,D=({host:e,site:t,key:n})=>`# Caddyfile, inside your site block
log {
    output file /var/log/caddy/access.log
    format json
}

# trckable-forward.sh /var/log/caddy/access.log
${T(e,n,`select((.request.headers["User-Agent"][0] // "") | test("${b()}"; "i")) | {s:"${t}",u:("https://"+.request.host+.request.uri),ua:.request.headers["User-Agent"][0],st:.status}`)}`,O=({host:e,site:t,key:n,domain:r})=>`# any language: one POST per robot request, after the page has gone
curl -X POST ${e}/api/crawl \\
  -H 'content-type: application/json' \\
  -H 'X-Trckable-Proxy-Key: ${n}' \\
  -d '{"s":"${t}","u":"https://${r}/page","ua":"<user agent>","st":200}'`;function k(e,t){switch(e){case`cloudflare`:return[{id:`worker`,lang:`js`,code:x(t)}];case`vercel`:return[{id:`middleware`,lang:`ts`,code:S(t)}];case`nginx`:return[{id:`mirror`,lang:`nginx`,code:w(t)},{id:`log`,lang:`nginx`,code:E(t)}];case`caddy`:return[{id:`caddy`,lang:`shell`,code:D(t)}];case`other`:return[{id:`curl`,lang:`shell`,code:O(t)}]}}var A=t(),j=_.setup,M=[`cloudflare`,`vercel`];function N(e,t){let[r,a]=(0,h.useState)(0);return(0,h.useEffect)(()=>{if(!t||r>0)return;let o=()=>{let t=i(e.timezone);d.aiSearch(e.id,{from:n(t,-1),to:t},1).then(e=>a(e.crawled)).catch(()=>void 0)};o();let s=setInterval(o,6e3);return()=>clearInterval(s)},[e.id,e.timezone,t,r]),r}function P({site:e,on:t,onChanged:n,onClose:r}){let[i,g]=(0,h.useState)(`cloudflare`),[_,v]=(0,h.useState)(t),[y,b]=(0,h.useState)(!1),[x,S]=(0,h.useState)(!1),C=N(e,_),w=(0,h.useMemo)(()=>({host:location.origin,site:e.id,key:e.proxy_key,domain:e.domain}),[e]),T=()=>{b(!0),d.setModule(e.id,`crawlers`,!0).then(()=>{v(!0),S(!0)}).catch(e=>a(e,T)).finally(()=>b(!1))},E=()=>{(x||C>0)&&n(),r()};return(0,A.jsxs)(u,{label:j.label,className:`wide`,onClose:E,children:[(0,A.jsx)(l,{heading:j.title,hint:j.hint,help:j.help}),(0,A.jsxs)(`ol`,{className:`cs-steps`,children:[(0,A.jsxs)(`li`,{children:[(0,A.jsx)(`b`,{children:j.steps[0]}),(0,A.jsx)(m,{prefix:`cs-`+e.id,label:j.steps[0],tabs:[...j.options],value:i,onChange:e=>g(e),sub:!0})]}),(0,A.jsxs)(`li`,{children:[(0,A.jsx)(`b`,{children:j.steps[1]}),k(i,w).map(e=>(0,A.jsxs)(`div`,{className:`cs-snippet`,children:[(0,A.jsx)(`span`,{className:`faint cs-caption`,children:j.captions[e.id]}),(0,A.jsx)(f,{lang:e.lang,code:e.code})]},e.id)),M.includes(i)&&(0,A.jsxs)(`div`,{className:`cs-key`,children:[(0,A.jsx)(`span`,{className:`faint`,children:j.keyHint}),(0,A.jsx)(p,{value:e.proxy_key,secret:!0})]})]}),(0,A.jsxs)(`li`,{children:[(0,A.jsx)(`b`,{children:j.steps[2]}),!_&&(0,A.jsx)(`button`,{type:`button`,className:`btn primary cs-on`,disabled:y,onClick:T,children:j.on}),_&&(0,A.jsxs)(`span`,{className:`cs-status`+(C>0?` done`:``),role:`status`,children:[C>0?(0,A.jsx)(s,{size:14,strokeWidth:2.25,"aria-hidden":`true`}):(0,A.jsx)(`span`,{className:`btn-spin`,"aria-hidden":`true`}),C>0?j.arrived(o(C)):j.waiting]})]})]}),(0,A.jsx)(c,{left:(0,A.jsx)(`a`,{className:`btn ghost`,href:`https://docs.trckable.com/reports/ai-search/`,target:`_blank`,rel:`noreferrer`,children:j.docs}),children:(0,A.jsx)(`button`,{type:`button`,className:`btn primary big`,onClick:E,children:j.done})})]})}var F=[`var(--ch-1)`,`var(--ch-2)`,`var(--ch-3)`,`var(--ch-4)`,`var(--ch-5)`,`var(--ch-6)`,`var(--ch-7)`],I=e=>F[Array.from(e).reduce((e,t)=>e+t.charCodeAt(0),0)%F.length];export{_ as a,v as i,P as n,g as r,I as t};