import{i as e,t}from"./react-e12729a5.js";import{Gr as n,Ur as r,Vt as i,jr as a,pr as o}from"./core-58de5bf0.js";import{t as s}from"./check-fc02cb76.js";import{t as c}from"./DialogActions-182d5027.js";import{t as l}from"./DialogHead-207e9271.js";import{t as u}from"./Modal-6ff3d456.js";import{t as d}from"./apiMore-52ff67ad.js";import{t as f}from"./Code-931f0ba3.js";var p=e(),m=t();function h({step:e,total:t,label:n}){return(0,m.jsxs)(`div`,{className:`stepper`,children:[(0,m.jsx)(`div`,{className:`stepper-bars`,role:`progressbar`,"aria-label":n,"aria-valuemin":1,"aria-valuemax":t,"aria-valuenow":e,children:Array.from({length:t},(t,n)=>(0,m.jsx)(`i`,{className:n<e?`on`:void 0},n))}),(0,m.jsx)(`span`,{className:`stepper-label`,children:n})]})}var g=n(`crawlers.kinds`,[{id:`answer`,label:`AI assistants`,what:`Fetched by an assistant to answer someone right now`},{id:`train`,label:`Training crawlers`,what:`Collected as training data`},{id:`index`,label:`Search bots`,what:`Crawled so your pages can be found`}]),_=n(`crawlers`,{title:`AI assistants & crawlers`,tabs:`What the robot wanted`,feed:`How to feed this`,empty:`Nothing yet. Robots never reach the browser script, so your server forwards them: see “How to feed this”.`,over:e=>`${e} over time`,none:e=>`No ${e.toLowerCase()} in this period.`,errors:(e,t)=>`${e} ${t?`requests`:`request`} hit an error page`,pages:`Pages read`,page:`Page`,bot:`Robot`,hits:`Hits`,other:`Other pages`,folded:e=>`${e} hits counted without their page (fair use)`,setup:{label:`Connect crawler data`,title:`Connect crawler data`,hint:`Robots run no JavaScript: your server or CDN reports them.`,help:`Only the robot’s name, the page and the time are sent. No address, no cookie, no visitor.`,titles:[`Where does your site run?`,`Add the code`,`Turn it on`],leads:[`Robots run no JavaScript, so your server or CDN reports them to us.`,`Paste it where your site runs. It never slows a visit down.`,`Crawlers show in AI & Search as soon as the first one arrives.`],step:(e,t)=>`Step ${e} of ${t}`,options:[{id:`cloudflare`,label:`Cloudflare`,sub:`a Worker`},{id:`vercel`,label:`Vercel`,sub:`middleware`},{id:`nginx`,label:`Nginx`,sub:`a log line`},{id:`caddy`,label:`Caddy`,sub:`a log line`},{id:`other`,label:`Other`,sub:`a plain HTTP call`}],captions:{worker:`A Worker, run after the page has gone out`,middleware:`Middleware, run after the response has gone`,mirror:`Mirror: no extra process, no status`,log:`Log and forwarder: reports the status too`,caddy:`Log and forwarder`,curl:`One POST per robot request`},copyCode:`Copy the code`,codeCopied:`Code copied`,showAll:`Show all`,showLess:`Show less`,copyKey:`Copy key`,keyCopied:`Key copied`,keyPaste:`Then save this key as a secret named TRCKABLE_PROXY_KEY in your host’s settings.`,back:`Back`,next:`I’ve added it`,waiting:`Waiting for the first robot…`,waitHint:`Deploy it. The first robot visit can take a few hours. You can close this: it shows up in AI & Search.`,connected:`Connected`,arrived:e=>`${e} hits arrived. Crawlers now show in AI & Search.`,docs:`Docs`,done:`Done`}}),v=`(other)`,y=[`chatgpt-user`,`oai-searchbot`,`claude-user`,`claude-searchbot`,`perplexity-user`,`perplexitybot`,`google-cloudvertexbot`,`bingbot-chat`,`duckassistbot`,`mistralai-user`,`gptbot`,`claudebot`,`anthropic-ai`,`google-extended`,`meta-externalagent`,`facebookbot`,`bytespider`,`ccbot`,`diffbot`,`omgili`,`timpibot`,`cohere-ai`,`cohere-training-data-crawler`,`mistralai-crawler`,`applebot-extended`],b=(e=`|`)=>y.join(e),x=({host:e,site:t,domain:n})=>`// Cloudflare Worker, on the route ${n}/*
// Settings → Variables and secrets: add the secret TRCKABLE_PROXY_KEY.
const BOTS = /${b()}/i

export default {
  async fetch(request, env, ctx) {
    const response = await fetch(request)
    const ua = request.headers.get('user-agent') || ''
    if (BOTS.test(ua)) {
      // After the page has gone: waitUntil never slows a visitor or a robot.
      ctx.waitUntil(
        fetch('${e}/api/crawl', {
          method: 'POST',
          headers: { 'content-type': 'application/json', 'x-trckable-proxy-key': env.TRCKABLE_PROXY_KEY },
          body: JSON.stringify({ s: '${t}', u: request.url, ua, st: response.status }),
        }).catch(() => {}),
      )
    }
    return response
  },
}`,S=({host:e,site:t})=>`// middleware.ts, next to package.json (Next.js)
// Project → Settings → Environment Variables: add TRCKABLE_PROXY_KEY.
// Other frameworks: the same body inside Vercel's middleware, with waitUntil from '@vercel/functions'.
import { NextResponse, type NextFetchEvent, type NextRequest } from 'next/server'

const BOTS = /${b()}/i

export function middleware(request: NextRequest, event: NextFetchEvent) {
  const ua = request.headers.get('user-agent') || ''
  if (BOTS.test(ua)) {
    event.waitUntil(
      fetch('${e}/api/crawl', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-trckable-proxy-key': process.env.TRCKABLE_PROXY_KEY! },
        body: JSON.stringify({ s: '${t}', u: request.url, ua }),
      }).catch(() => {}),
    )
  }
  return NextResponse.next()
}

export const config = { matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'] }`,C=()=>String.raw`# http { }: the robot's token, or nothing. An address with a quote or a backslash in it is skipped.
map $http_user_agent $trk_bot { default ""; ~*(?<t>${b()}) $t; }
map "$host$request_uri" $trk_url { default "$host$request_uri"; ~[\x22\x5c] ""; }`,w=({host:e,site:t,key:n})=>`${C()}

# server { }
location / {
    mirror /_trckable;
    mirror_request_body off;
    # ... your usual proxy_pass, root or try_files
}
location = /_trckable {
    internal;
    if ($trk_bot = "") { return 204; }
    if ($trk_url = "") { return 204; }
    proxy_pass ${e}/api/crawl;
    proxy_ssl_server_name on;
    proxy_method POST;
    proxy_set_header Content-Type application/json;
    proxy_set_header X-Trckable-Proxy-Key ${n};
    proxy_set_body '{"s":"${t}","u":"https://$trk_url","ua":"$trk_bot"}';
}`,T=(e,t,n)=>`#!/bin/sh
# Reads the log as it grows and reports each robot. Needs jq and curl; run it as a service.
tail -Fn0 "$1" | jq -c --unbuffered '${n}' | while read -r body; do
  curl -s -o /dev/null -X POST ${e}/api/crawl \\
    -H 'content-type: application/json' -H 'X-Trckable-Proxy-Key: ${t}' -d "$body"
done`,E=({host:e,site:t,key:n})=>`${C()}

# http { }: one line per robot, and nothing for anyone else.
log_format trckable escape=json '{"host":"$host","uri":"$request_uri","ua":"$http_user_agent","status":$status}';
access_log /var/log/nginx/trckable.log trckable if=$trk_bot;

# trckable-forward.sh /var/log/nginx/trckable.log
${T(e,n,`{s:"${t}",u:("https://"+.host+.uri),ua:.ua,st:.status}`)}`,D=({host:e,site:t,key:n})=>`# Caddyfile, inside your site block
log {
    output file /var/log/caddy/access.log
    format json
}

# trckable-forward.sh /var/log/caddy/access.log
${T(e,n,`select((.request.headers["User-Agent"][0] // "") | test("${b()}"; "i")) | {s:"${t}",u:("https://"+.request.host+.request.uri),ua:.request.headers["User-Agent"][0],st:.status}`)}`,O=({host:e,site:t,key:n,domain:r})=>`# any language: one POST per robot request, after the page has gone
curl -X POST ${e}/api/crawl \\
  -H 'content-type: application/json' \\
  -H 'X-Trckable-Proxy-Key: ${n}' \\
  -d '{"s":"${t}","u":"https://${r}/page","ua":"<user agent>","st":200}'`;function k(e,t){switch(e){case`cloudflare`:return[{id:`worker`,lang:`js`,code:x(t)}];case`vercel`:return[{id:`middleware`,lang:`ts`,code:S(t)}];case`nginx`:return[{id:`mirror`,lang:`nginx`,code:w(t)},{id:`log`,lang:`nginx`,code:E(t)}];case`caddy`:return[{id:`caddy`,lang:`shell`,code:D(t)}];case`other`:return[{id:`curl`,lang:`shell`,code:O(t)}]}}var A=_.setup,j=[`cloudflare`,`vercel`];function M({value:e,label:t,done:n,big:r}){let[i,a]=(0,p.useState)(!1),s=()=>{navigator.clipboard?.writeText(e).then(()=>{a(!0),setTimeout(()=>a(!1),1500)}).catch(e=>o(e,s))};return(0,m.jsx)(`button`,{type:`button`,className:`btn`+(r?` primary big`:``),onClick:s,children:i?n:t})}function N({setup:e,plan:t}){let[n,r]=(0,p.useState)(!1),i=k(e,t);return(0,m.jsxs)(`div`,{className:`cs-code`,children:[(0,m.jsx)(`div`,{className:`cs-fold`+(n?` open`:``),children:i.map(e=>(0,m.jsxs)(`div`,{className:`cs-snippet`,children:[(0,m.jsx)(`span`,{className:`faint cs-caption`,children:A.captions[e.id]}),(0,m.jsx)(f,{lang:e.lang,code:e.code})]},e.id))}),(0,m.jsxs)(`div`,{className:`cs-row`,children:[(0,m.jsx)(M,{big:!0,value:i.map(e=>e.code).join(`

`),label:A.copyCode,done:A.codeCopied}),(0,m.jsx)(`button`,{type:`button`,className:`cs-link`,"aria-expanded":n,onClick:()=>r(!n),children:n?A.showLess:A.showAll})]}),j.includes(e)&&(0,m.jsxs)(`div`,{className:`cs-key`,children:[(0,m.jsx)(`span`,{className:`faint`,children:A.keyPaste}),(0,m.jsx)(M,{value:t.key,label:A.copyKey,done:A.keyCopied})]})]})}var P=_.setup,F=3;function I(e,t){let[n,i]=(0,p.useState)(0);return(0,p.useEffect)(()=>{if(!t||n>0)return;let o=()=>{let t=r(e.timezone);d.aiSearch(e.id,{from:a(t,-1),to:t},1).then(e=>i(e.crawled)).catch(()=>void 0)};o();let s=setInterval(o,6e3);return()=>clearInterval(s)},[e.id,e.timezone,t,n]),n}function L({site:e,on:t,onChanged:n,onClose:r}){let[a,f]=(0,p.useState)(1),[g,_]=(0,p.useState)(`cloudflare`),[v,y]=(0,p.useState)(t),[b,x]=(0,p.useState)(!1),[S,C]=(0,p.useState)(!1),w=I(e,v),T=(0,p.useMemo)(()=>({host:location.origin,site:e.id,key:e.proxy_key,domain:e.domain}),[e]),E=(0,p.useRef)(null),D=(0,p.useRef)(!0);(0,p.useEffect)(()=>{if(D.current){D.current=!1;return}let e=E.current?.querySelector(`h2`);e?.setAttribute(`tabindex`,`-1`),e?.focus()},[a]);let O=e=>{_(e),f(2)},k=()=>{if(v){f(3);return}x(!0),d.setModule(e.id,`crawlers`,!0).then(()=>{y(!0),C(!0),f(3)}).catch(e=>o(e,k)).finally(()=>x(!1))},A=()=>{(S||w>0)&&n(),r()},j=P.options.find(e=>e.id===g)?.label;return(0,m.jsxs)(u,{label:P.label,className:`wide`,onClose:A,children:[(0,m.jsxs)(`div`,{ref:E,className:`cs-top`,children:[(0,m.jsx)(h,{step:a,total:F,label:P.step(a,F)}),(0,m.jsx)(l,{heading:P.titles[a-1],hint:P.leads[a-1],help:P.help})]}),(0,m.jsxs)(`div`,{className:`cs-body`,children:[a===1&&(0,m.jsx)(`div`,{className:`cs-tiles`,role:`group`,"aria-label":P.titles[0],children:P.options.map(e=>(0,m.jsxs)(`button`,{type:`button`,className:`cs-tile`,onClick:()=>O(e.id),children:[(0,m.jsx)(`b`,{children:e.label}),(0,m.jsx)(`span`,{className:`faint`,children:e.sub})]},e.id))}),a===2&&(0,m.jsx)(N,{setup:g,plan:T}),a===3&&(0,m.jsxs)(`div`,{className:`cs-wait`,role:`status`,children:[w>0?(0,m.jsx)(`span`,{className:`cs-ok`,children:(0,m.jsx)(s,{size:28,strokeWidth:2.25,"aria-hidden":`true`})}):(0,m.jsx)(`span`,{className:`cs-ring`,"aria-hidden":`true`}),(0,m.jsx)(`h3`,{children:w>0?P.connected:P.waiting}),(0,m.jsx)(`p`,{className:`faint`,children:w>0?P.arrived(i(w)):P.waitHint})]})]},a),(0,m.jsxs)(c,{left:a===1?(0,m.jsx)(`a`,{className:`btn ghost`,href:`https://docs.trckable.com/reports/ai-search/`,target:`_blank`,rel:`noreferrer`,children:P.docs}):(0,m.jsx)(`button`,{type:`button`,className:`btn ghost`,onClick:()=>f(a-1),children:P.back}),children:[a>1&&(0,m.jsx)(`span`,{className:`cs-chip`,children:j}),a===2&&(0,m.jsx)(`button`,{type:`button`,className:`btn primary big`,disabled:b,onClick:k,children:P.next}),a===3&&(0,m.jsx)(`button`,{type:`button`,className:`btn primary big`,onClick:A,children:P.done})]})]})}var R=[`var(--ch-1)`,`var(--ch-2)`,`var(--ch-3)`,`var(--ch-4)`,`var(--ch-5)`,`var(--ch-6)`,`var(--ch-7)`],z=e=>R[Array.from(e).reduce((e,t)=>e+t.charCodeAt(0),0)%R.length];export{_ as a,v as i,L as n,g as r,z as t};