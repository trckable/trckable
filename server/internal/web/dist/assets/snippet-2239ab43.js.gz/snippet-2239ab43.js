var e=e=>e.cookieless?` cookieless`:``,t=e=>e.cookieless?`, cookieless: true`:``,n=e=>`init({ site: '${e.site}', host: '${e.host}'${t(e)} })`,r=e=>t=>e(t).map(e=>e.code).join(`

`),i=t=>`<Analytics site="${t.site}"${e(t)} />`,a=t=>`<Analytics site="${t.site}" host="${t.host}"${e(t)} />`,o=e=>[{title:`Install the package`,code:`npm i trckable`},{title:`Add it to app/layout.tsx`,code:`import { Analytics } from 'trckable/next'\n${i(e)}`},{title:`Add one route, so events go through your own domain`,code:`// app/api/e/route.ts — same-origin: past analytics blocklists, 400-day Safari visitors
export { POST } from 'trckable/next'`},{title:`Set two environment variables`,code:`# .env\nTRCKABLE_HOST=${e.host}\nTRCKABLE_PROXY_KEY=${e.proxyKey}`}],s=e=>[{title:`Install the package`,code:`npm i trckable`},{title:`Initialise it once, anywhere in your app tree`,code:`import { Analytics } from 'trckable/react'\n${a(e)}`}],c=({host:e,site:t,domain:n},r=``,i=`${e}/js/${t}.js`,a=``)=>[`<script`,`  defer`,`  data-site="${t}"`,`  data-domain="${n}"`,...a?[`  data-api="${a}"`]:[],`  src="${i}">`,`<\/script>`].join(`
`+r),l=({host:e,site:t,domain:n})=>`{ src: '${e}/js/${t}.js', defer: true, 'data-site': '${t}', 'data-domain': '${n}' }`,u=[{id:`script`,name:`Script tag`,group:`Code`,where:`In the <head> of every page.`,code:c,note:`Works anywhere HTML can be edited. This file holds only the modules you turned on.`,keywords:`html snippet head`},{id:`next`,name:`Next.js`,group:`Frameworks`,where:`app/layout.tsx, plus one route so events go through your own domain.`,code:r(o),steps:o,bundled:!0,note:`The most accurate install: nothing to block, and the cookie is first-party.`,keywords:`vercel app router proxy`},{id:`landing`,name:`Landing page and app`,group:`Code`,where:`The tag on the landing page, trckable/next in the app on a subdomain.`,code:e=>`<!-- landing page, in <head> -->
${c(e)}

`+r(o)(e),bundled:!0,note:`data-domain shares the cookie with the app: one visitor, one journey, sales included.`,keywords:`subdomain saas marketing cross-domain`},{id:`react`,name:`npm / React`,group:`Frameworks`,where:`Anywhere in your app tree (Vite, CRA, React Router).`,code:r(s),steps:s,bundled:!0,note:`The tracker is bundled into your app (about 2 KB), so there is no script file to block.`,keywords:`vite spa`},{id:`vue`,name:`Vue & Nuxt`,group:`Frameworks`,where:`main.ts, or app.head in nuxt.config.`,code:e=>`npm i trckable

// main.ts
import { init } from 'trckable'
${n(e)}

// or nuxt.config.ts
app: { head: { script: [${l(e)}] } }`,bundled:!0,keywords:`nuxt vue3`},{id:`svelte`,name:`Svelte & SvelteKit`,group:`Frameworks`,where:`src/app.html (SvelteKit) or your root component.`,code:e=>`<!-- src/app.html, inside <head> -->
${c(e)}

<!-- or, bundled: -->
import { init } from 'trckable'
${n(e)}`,bundled:!0,keywords:`sveltekit`},{id:`astro`,name:`Astro`,group:`Frameworks`,where:`Your base layout, inside <head>.`,code:e=>`---
// src/layouts/Base.astro
---
<head>
  ${c(e,`  `)}
</head>`,keywords:`starlight static`},{id:`remix`,name:`Remix / React Router`,group:`Frameworks`,where:`root.tsx, in the <head> of the document.`,code:e=>`// app/root.tsx
<head>
  <Meta />
  <Links />
  ${c(e,`  `)}
</head>`,keywords:`react-router`},{id:`gatsby`,name:`Gatsby`,group:`Frameworks`,where:`gatsby-ssr.js, through setHeadComponents.`,code:({site:e,host:t,domain:n})=>`// gatsby-ssr.js
exports.onRenderBody = ({ setHeadComponents }) =>
  setHeadComponents([
    <script key="trckable" defer data-site="${e}" data-domain="${n}" src="${t}/js/${e}.js" />,
  ])`},{id:`angular`,name:`Angular`,group:`Frameworks`,where:`src/index.html, inside <head>.`,code:c},{id:`static`,name:`Hugo, Jekyll, Eleventy`,group:`Frameworks`,where:`Your layout partial for <head> (layouts/partials/head.html, _includes/head.html).`,code:c,keywords:`static site generator 11ty`},{id:`docusaurus`,name:`Docusaurus`,group:`Frameworks`,where:`docusaurus.config.js, in scripts.`,code:e=>`// docusaurus.config.js
scripts: [${l(e)}],`},{id:`wordpress`,name:`WordPress`,group:`CMS & shops`,where:`Appearance → Theme File Editor → header.php, or a header-scripts plugin (WPCode, Insert Headers and Footers).`,code:e=>`<?php // functions.php of your child theme
add_action('wp_head', function () { ?>
  ${c(e,`  `)}
<?php });`,note:`A plugin is safer than editing the theme: a theme update overwrites header.php.`,keywords:`wp woocommerce plugin`},{id:`shopify`,name:`Shopify`,group:`CMS & shops`,where:`Online Store → Themes → Edit code → layout/theme.liquid, just before </head>.`,code:c,note:`theme.liquid covers the storefront only. Checkout runs on Shopify’s own pages: add the same script as a custom pixel under Settings → Customer events. checkout.liquid and Additional scripts stop firing on 26 August 2026.`,keywords:`liquid ecommerce checkout pixel`},{id:`ghost`,name:`Ghost`,group:`CMS & shops`,where:`Settings → Code injection → Site header.`,code:c},{id:`webflow`,name:`Webflow`,group:`Site builders`,where:`Site settings → Custom code → Head code, then publish.`,code:c,note:`Custom code needs a paid site plan.`},{id:`framer`,name:`Framer`,group:`Site builders`,where:`Site settings → General → Custom code → Start of <head> tag.`,code:c,note:`Custom code needs a paid site plan.`},{id:`squarespace`,name:`Squarespace`,group:`Site builders`,where:`Settings → Advanced → Code injection → Header.`,code:c,note:`Code injection needs a Core plan or higher (legacy Business/Commerce also works).`},{id:`wix`,name:`Wix`,group:`Site builders`,where:`Settings → Advanced → Custom code → Add code, on All pages, loaded in the Head.`,code:c,note:`Site-wide custom code needs a paid Wix plan.`},{id:`carrd`,name:`Carrd`,group:`Site builders`,where:`Site settings → Code → Head.`,code:c,note:`Needs a Carrd Pro plan.`},{id:`bubble`,name:`Bubble`,group:`Site builders`,where:`Settings → SEO / metatags → Script in the header.`,code:c},{id:`notion`,name:`Notion sites (Super, Potion)`,group:`Site builders`,where:`Your host’s custom code / head field.`,code:c,note:`Notion’s own public pages cannot run scripts; a host like Super or Potion can.`},{id:`gtm`,name:`Google Tag Manager`,group:`Site builders`,where:`A Custom HTML tag firing on All Pages.`,code:c,note:`One more thing between you and your data, and tag managers are blocked more often than first-party scripts. Prefer the script tag when you can.`,keywords:`gtm tag manager`},{id:`lovable`,name:`Lovable, Bolt, v0, Replit`,group:`AI builders`,where:`index.html, inside <head> — ask the builder to add it.`,code:e=>`Add this to index.html inside <head>:

${c(e)}`,note:`These generate a normal Vite app, so the React package works too.`,keywords:`ai builder vibe coding`},{id:`backend`,name:`Laravel, Rails, Django`,group:`Frameworks`,where:`Your layout template, inside <head>.`,code:c,note:`Blade, ERB, Twig, Jinja — anywhere the layout renders <head>.`,keywords:`php ruby python blade erb jinja twig symfony flask`},{id:`other-js`,name:`Solid, Qwik, Ember, Flutter web`,group:`Frameworks`,where:`index.html (web/index.html for Flutter), inside <head>.`,code:c,keywords:`solidjs qwik ember flutter preact lit stencil`},{id:`drupal`,name:`Drupal`,group:`CMS & shops`,where:`Your theme's html.html.twig, before </head>, or a header-scripts module.`,code:c,keywords:`twig cms`},{id:`joomla`,name:`Joomla`,group:`CMS & shops`,where:`Your template's index.php, before </head>.`,code:c},{id:`magento`,name:`Magento 2`,group:`CMS & shops`,where:`Content → Design → Configuration → edit your store view → HTML Head → Scripts and Style Sheets.`,code:c,note:`Pick Global to cover every store view.`,keywords:`adobe commerce`},{id:`prestashop`,name:`PrestaShop`,group:`CMS & shops`,where:`Your theme's header.tpl, before </head>.`,code:c},{id:`bigcommerce`,name:`BigCommerce`,group:`CMS & shops`,where:`Storefront → Script Manager → Create a script, placed in the Head on all pages.`,code:c,keywords:`ecommerce`},{id:`hubspot`,name:`HubSpot CMS`,group:`Site builders`,where:`Settings → Website → Pages → Site header HTML.`,code:c},{id:`blogger`,name:`Blogger`,group:`Site builders`,where:`Theme → Edit HTML, before </head>.`,code:c},{id:`weebly`,name:`Weebly / Square Online`,group:`Site builders`,where:`Settings → SEO → Header code.`,code:c},{id:`softr`,name:`Softr`,group:`Site builders`,where:`Settings → Custom code → Header.`,code:c},{id:`discourse`,name:`Discourse`,group:`CMS & shops`,where:`Admin → Customize → Themes → Edit CSS/HTML → </head>.`,code:c,keywords:`forum community`},{id:`node`,name:`Hono, Bun, Deno, Workers`,group:`Apps & servers`,where:`One route on your own domain that forwards events, and the tag sending to it.`,code:e=>`// the route: any handler that takes a Request
import { proxy } from 'trckable/server'

const forward = proxy({ host: '${e.host}', proxyKey: process.env.TRCKABLE_PROXY_KEY })
app.post('/api/e', (c) => forward(c.req.raw))

# .env
TRCKABLE_PROXY_KEY=${e.proxyKey}

<!-- every page, in <head> -->
${c(e,``,void 0,`/api/e`)}`,note:`Same-origin, so nothing can block it and Safari keeps visitors 400 days. Express and Fastify: turn the request into a Request first (@hono/node-server does).`,keywords:`node bun deno cloudflare middleware express fastify`},{id:`server`,name:`Server-side (any language)`,group:`Apps & servers`,where:`Send events straight to the HTTP API.`,code:({host:e,site:t,domain:n})=>`curl -X POST ${e}/api/e \\
  -H 'content-type: application/json' \\
  -H "user-agent: <the visitor's browser user agent>" \\
  -d '{"s":"${t}","k":"pv","u":"https://${n}/pricing"}'`,note:`For backends, queues and native apps. Pass the visitor’s own user agent: requests that name no browser (curl, Go, Python, Node fetch) are counted as bots and dropped.`,keywords:`api node python go php ruby laravel rails django`},{id:`proxy`,name:`Proxy on your own domain`,group:`Apps & servers`,where:`Nginx, Caddy, Cloudflare Workers or Vercel rewrites.`,code:e=>`# Nginx
location /t.js {
  proxy_pass ${e.host}/js/${e.site}.js;
  proxy_ssl_server_name on;
}
location /api/e {
  proxy_pass ${e.host}/api/e;
  proxy_ssl_server_name on;
  proxy_set_header X-Trckable-Client-IP $remote_addr;
  proxy_set_header X-Trckable-Proxy-Key ${e.proxyKey};
}

<!-- every page, in <head>: the script and its events from your domain -->
${c(e,``,`/t.js`)}`,note:`Same-origin: no blocker list, and the visitor cookie lasts 400 days in Safari. Keep the proxy key secret.`,keywords:`nginx caddy cloudflare vercel rewrite first-party`},{id:`crawlers`,name:`AI assistants & crawlers`,group:`Apps & servers`,where:`One middleware on your own server — robots never run the browser script.`,code:({host:e,site:t})=>`// Next.js — middleware.ts
import { reportCrawler } from 'trckable/server'

export function middleware(req) {
  reportCrawler({
    host: '${e}',
    site: '${t}',
    key: process.env.TRCKABLE_PROXY_KEY,
    url: req.url,
    ua: req.headers.get('user-agent'),
  })
}`,note:`Turn the AI crawlers module on first (Settings → Modules), or nothing is recorded: then it shows who reads you to answer questions, who indexes you, and who collects training data. It needs TRCKABLE_PROXY_KEY on the server.`,keywords:`gptbot chatgpt claude perplexity googlebot ai crawler robots seo`},{id:`app`,name:`Electron, Tauri, PWA`,group:`Apps & servers`,where:`The npm package, in an app served from your site’s domain.`,code:e=>`import { init } from 'trckable'
${n(e)}`,bundled:!0,note:`Screens are tracked as paths. Only pages on your site’s domain (or a subdomain) count: an Electron or Tauri window loading file:// or localhost is not, so send those screens from your backend with the HTTP API (Server-side).`}],d=[`script`,`next`,`wordpress`,`react`],f=e=>u.find(t=>t.id===e)??u[0],p=e=>f(`script`).code(e);function m(e,t){return e.steps?e.steps(t):[{title:``,code:e.code(t)}]}var h=`https://trckable.com/docs/`,g={script:`install/script-tag/`,next:`install/npm/`,react:`install/npm/`,vue:`install/npm/`,svelte:`install/npm/`,app:`install/platforms/#electron-and-tauri`,node:`install/proxy/`,proxy:`install/proxy/`,wordpress:`install/platforms/#wordpress`,shopify:`install/platforms/#shopify`,webflow:`install/platforms/#webflow`,framer:`install/platforms/#framer`,squarespace:`install/platforms/#squarespace-and-wix`,wix:`install/platforms/#squarespace-and-wix`,ghost:`install/platforms/#ghost`,astro:`install/platforms/#astro-hugo-docusaurus-jekyll`,static:`install/platforms/#astro-hugo-docusaurus-jekyll`,docusaurus:`install/platforms/#astro-hugo-docusaurus-jekyll`,gtm:`install/platforms/#google-tag-manager`,lovable:`install/platforms/#lovable-bolt-v0-replit`},_={Code:`install/script-tag/`,Frameworks:`install/script-tag/`,"Site builders":`install/platforms/#anything-not-listed`,"CMS & shops":`install/platforms/#anything-not-listed`,"AI builders":`install/platforms/#lovable-bolt-v0-replit`,"Apps & servers":`install/`},v=e=>h+(g[e.id]??_[e.group]),y=h+`privacy/`,b=h+`migrate/`;export{f as a,u as c,v as i,n as l,y as n,m as o,d as r,p as s,b as t,i as u};